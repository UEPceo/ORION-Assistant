plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.orion.voicelab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.orion.voicelab"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    // Official sherpa-onnx Android/Kotlin package. Native runtime is included.
    implementation("com.github.k2-fsa.sherpa-onnx:sherpa-onnx:v1.13.8")
    // Used only for the first-run download and safe extraction of the official .tar.bz2 model.
    implementation("org.apache.commons:commons-compress:1.27.1")
}
