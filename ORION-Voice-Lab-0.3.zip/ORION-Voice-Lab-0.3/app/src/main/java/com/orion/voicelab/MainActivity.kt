package com.orion.voicelab

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineMoonshineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Acumulador de tiempos de reconocimiento. Solo se modifica desde el hilo principal. */
private class AsrStats {
    var count = 0
    var audioMs = 0L
    var decodeMs = 0L
    var maxDecodeMs = 0L

    fun add(audio: Long, decode: Long) {
        count++
        audioMs += audio
        decodeMs += decode
        if (decode > maxDecodeMs) maxDecodeMs = decode
    }

    /** Factor de tiempo real: < 1 significa que decodifica más rápido que el audio. */
    val rtf: Double get() = if (audioMs > 0) decodeMs.toDouble() / audioMs else 0.0
    val avgDecodeMs: Long get() = if (count > 0) decodeMs / count else 0L

    fun reset() {
        count = 0; audioMs = 0; decodeMs = 0; maxDecodeMs = 0
    }
}

/**
 * ORION Voice Lab 0.3
 * Español offline: Silero VAD (segmentación) + Moonshine Base ES v2 (reconocimiento) con sherpa-onnx,
 * más un panel de medición para la Fase 0 (latencia, RAM, batería, temperatura).
 */
class MainActivity : Activity() {
    companion object {
        private const val SAMPLE_RATE = 16_000
        private const val PERMISSION_REQUEST = 701
        private const val MODEL_DIR_NAME = "sherpa-onnx-moonshine-base-es-quantized-2026-02-27"
        private const val MODEL_ARCHIVE = "$MODEL_DIR_NAME.tar.bz2"
        private const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$MODEL_ARCHIVE"

        // Silero VAD (modelo incluido en assets/silero_vad.onnx)
        private const val VAD_ASSET = "silero_vad.onnx"
        private const val VAD_WINDOW = 512            // muestras por ventana a 16 kHz (32 ms)
        private const val VAD_THRESHOLD = 0.5f
        private const val VAD_MIN_SILENCE_S = 0.5f    // pausa que cierra la frase
        private const val VAD_MIN_SPEECH_S = 0.25f
        private const val VAD_MAX_SPEECH_S = 12.0f
        private const val MIN_SEGMENT_SAMPLES = SAMPLE_RATE / 4

        private const val METRICS_TICK_MS = 15_000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    @Volatile private var destroyed = false

    // Hilo único y "daemon" para decodificar; las liberaciones del reconocedor pasan por él
    // para no liberar el modelo mientras se decodifica una frase.
    private val asrExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "OrionAsr").apply { isDaemon = true }
    }

    @Volatile private var recognizer: OfflineRecognizer? = null
    private var recorder: AudioRecord? = null

    private val stats = AsrStats()
    @Volatile private var modelLoadMs = -1L
    private var sessionStartMs = 0L
    private var sessionEndMs = 0L
    private var startSnapshot: DeviceMetrics.Snapshot? = null
    private var endSnapshot: DeviceMetrics.Snapshot? = null
    private var peakPssMb = 0L
    private var minAvailMb = Long.MAX_VALUE

    private lateinit var status: TextView
    private lateinit var metricsView: TextView
    private lateinit var transcript: TextView
    private lateinit var progress: ProgressBar
    private lateinit var downloadButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val modelDirectory: File
        get() = File(filesDir, "models/$MODEL_DIR_NAME")

    private val metricsTicker = object : Runnable {
        override fun run() {
            if (!running.get()) return
            refreshMetrics()
            mainHandler.postDelayed(this, METRICS_TICK_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 26)
        window.navigationBarColor = Color.rgb(8, 13, 26)
        buildUi()
        refreshModelState()
        refreshMetrics()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(Color.rgb(8, 13, 26))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "ORION"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "VOICE LAB 0.3 · ESPAÑOL OFFLINE"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(53, 215, 242))
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(12))
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
        }
        downloadButton = Button(this).apply {
            text = "Descargar modelo español (una vez)"
            setOnClickListener { downloadModel() }
        }
        startButton = Button(this).apply {
            text = "Iniciar reconocimiento"
            isEnabled = false
            setOnClickListener { requestPermissionAndStart() }
        }
        stopButton = Button(this).apply {
            text = "Detener escucha"
            isEnabled = false
            setOnClickListener { stopListening() }
        }
        val toolsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        toolsRow.addView(Button(this).apply {
            text = "Medir ahora"
            setOnClickListener { refreshMetrics() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        toolsRow.addView(Button(this).apply {
            text = "Copiar informe"
            setOnClickListener { copyReport() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        toolsRow.addView(Button(this).apply {
            text = "Borrar datos"
            setOnClickListener { resetMeasurements() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        metricsView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(140, 200, 215))
            setPadding(0, dp(10), 0, dp(6))
        }
        transcript = TextView(this).apply {
            text = "Aquí aparecerán las transcripciones.\n\nEl audio se procesa en el teléfono y no se envía a ningún servidor."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
        }
        root.addView(status)
        root.addView(progress)
        root.addView(downloadButton)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(toolsRow)
        root.addView(metricsView)
        root.addView(ScrollView(this).apply { addView(transcript) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun refreshModelState() {
        val ready = modelFilesPresent()
        status.text = if (ready) {
            "Moonshine Base ES instalado. Reconocimiento local disponible sin Internet."
        } else {
            "Modelo español todavía no instalado. Descárgalo con conexión Wi-Fi. Después funcionará offline."
        }
        downloadButton.isEnabled = !ready
        startButton.isEnabled = ready && !busy.get()
    }

    private fun modelFilesPresent(): Boolean =
        File(modelDirectory, "encoder_model.ort").isFile &&
        File(modelDirectory, "decoder_model_merged.ort").isFile &&
        File(modelDirectory, "tokens.txt").isFile

    private fun modelSizeMb(): Long =
        if (modelDirectory.isDirectory) modelDirectory.walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024) else 0L

    // ---------------------------------------------------------------- descarga del modelo

    private fun downloadModel() {
        downloadButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        status.text = "Descargando modelo oficial Moonshine Base ES…"
        thread(name = "OrionModelDownload") {
            var connection: HttpURLConnection? = null
            try {
                val archive = File(cacheDir, MODEL_ARCHIVE)
                connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    connect()
                }
                if (connection.responseCode !in 200..299) {
                    error("Descarga HTTP ${connection.responseCode}")
                }
                val total = connection.contentLengthLong
                connection.inputStream.use { input ->
                    FileOutputStream(archive).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var count: Int
                        var copied = 0L
                        while (input.read(buffer).also { count = it } >= 0) {
                            if (count == 0) continue
                            output.write(buffer, 0, count)
                            copied += count
                            if (total > 0) {
                                val percent = ((copied * 100) / total).toInt().coerceIn(0, 100)
                                mainHandler.post { progress.progress = percent }
                            }
                        }
                    }
                }
                extractModelArchive(archive)
                archive.delete()
                mainHandler.post {
                    progress.visibility = ProgressBar.GONE
                    refreshModelState()
                    refreshMetrics()
                }
            } catch (e: Exception) {
                mainHandler.post {
                    progress.visibility = ProgressBar.GONE
                    status.text = "No se pudo instalar el modelo: ${e.message ?: "error desconocido"}"
                    downloadButton.isEnabled = true
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun extractModelArchive(archive: File) {
        val allowed = setOf("encoder_model.ort", "decoder_model_merged.ort", "tokens.txt", "LICENSE")
        val tempDir = File(filesDir, "models/$MODEL_DIR_NAME.tmp")
        tempDir.deleteRecursively()
        check(tempDir.mkdirs() || tempDir.isDirectory) { "No se pudo crear el directorio del modelo" }
        BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
            TarArchiveInputStream(bz).use { tar ->
                while (true) {
                    val entry = tar.nextTarEntry ?: break
                    if (!entry.isFile) continue
                    val name = entry.name.substringAfterLast('/')
                    if (name !in allowed) continue
                    val target = File(tempDir, name)
                    FileOutputStream(target).use { out -> tar.copyTo(out) }
                }
            }
        }
        check(File(tempDir, "encoder_model.ort").length() > 1_000_000) { "Falta encoder_model.ort" }
        check(File(tempDir, "decoder_model_merged.ort").length() > 1_000_000) { "Falta decoder_model_merged.ort" }
        check(File(tempDir, "tokens.txt").length() > 1_000) { "Falta tokens.txt" }
        modelDirectory.deleteRecursively()
        check(tempDir.renameTo(modelDirectory)) { "No se pudo activar el modelo descargado" }
    }

    // ---------------------------------------------------------------- permisos y arranque

    private fun requestPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), PERMISSION_REQUEST)
        } else startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            status.text = "Permiso de micrófono denegado."
        }
    }

    private fun createRecognizer(): OfflineRecognizer {
        val encoder = File(modelDirectory, "encoder_model.ort").absolutePath
        val decoder = File(modelDirectory, "decoder_model_merged.ort").absolutePath
        val tokens = File(modelDirectory, "tokens.txt").absolutePath
        val moonshine = OfflineMoonshineModelConfig(
            encoder = encoder,
            mergedDecoder = decoder
        )
        val modelConfig = OfflineModelConfig(
            moonshine = moonshine,
            tokens = tokens,
            numThreads = 2,
            debug = false,
            provider = "cpu"
        )
        val config = OfflineRecognizerConfig(
            modelConfig = modelConfig,
            decodingMethod = "greedy_search"
        )
        return OfflineRecognizer(config = config)
    }

    private fun createVad(): Vad {
        val config = VadModelConfig(
            sileroVadModelConfig = SileroVadModelConfig(
                model = VAD_ASSET,
                threshold = VAD_THRESHOLD,
                minSilenceDuration = VAD_MIN_SILENCE_S,
                minSpeechDuration = VAD_MIN_SPEECH_S,
                windowSize = VAD_WINDOW,
                maxSpeechDuration = VAD_MAX_SPEECH_S
            ),
            sampleRate = SAMPLE_RATE,
            numThreads = 1,
            provider = "cpu",
            debug = false
        )
        return Vad(assets, config)
    }

    private fun startListening() {
        if (!modelFilesPresent() || !busy.compareAndSet(false, true)) return
        status.text = "Cargando Moonshine Base ES y Silero VAD…"
        startButton.isEnabled = false
        thread(name = "OrionCapture") {
            var audioRecord: AudioRecord? = null
            var vad: Vad? = null
            try {
                val loadStart = SystemClock.elapsedRealtime()
                recognizer = createRecognizer()
                vad = createVad()
                modelLoadMs = SystemClock.elapsedRealtime() - loadStart

                val minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                check(minBuffer > 0) { "No se pudo obtener el búfer de audio" }
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuffer * 2, 4096)
                )
                check(audioRecord.state == AudioRecord.STATE_INITIALIZED) { "No se pudo inicializar el micrófono" }
                recorder = audioRecord
                if (destroyed) return@thread

                val begin = DeviceMetrics.snapshot(this, filesDir)
                mainHandler.post {
                    startSnapshot = begin
                    endSnapshot = null
                    sessionStartMs = SystemClock.elapsedRealtime()
                    sessionEndMs = 0L
                    peakPssMb = begin.appPssMb
                    minAvailMb = begin.availRamMb
                }

                running.set(true)
                audioRecord.startRecording()
                mainHandler.post {
                    status.text = "Escuchando. Habla con naturalidad; la frase se cierra tras una pausa."
                    stopButton.isEnabled = true
                    refreshMetrics()
                    mainHandler.removeCallbacks(metricsTicker)
                    mainHandler.postDelayed(metricsTicker, METRICS_TICK_MS)
                }
                captureLoop(audioRecord, vad)
            } catch (e: Exception) {
                mainHandler.post { status.text = "Error: ${e.message ?: "desconocido"}" }
            } finally {
                running.set(false)
                try { audioRecord?.stop() } catch (_: Exception) {}
                try { audioRecord?.release() } catch (_: Exception) {}
                recorder = null
                try { vad?.release() } catch (_: Exception) {}
                releaseRecognizerAfterPendingWork()
                val finish = try { DeviceMetrics.snapshot(this, filesDir) } catch (_: Exception) { null }
                mainHandler.post {
                    if (finish != null && startSnapshot != null) {
                        endSnapshot = finish
                        sessionEndMs = SystemClock.elapsedRealtime()
                    }
                    busy.set(false)
                    stopButton.isEnabled = false
                    startButton.isEnabled = modelFilesPresent()
                    if (!status.text.startsWith("Error")) {
                        status.text = "Escucha detenida. El modelo permanece instalado para uso offline."
                    }
                    refreshMetrics()
                }
            }
        }
    }

    /** Lee micrófono en ventanas de 32 ms y deja que Silero VAD decida dónde empieza y acaba cada frase. */
    private fun captureLoop(audioRecord: AudioRecord, vad: Vad) {
        val shortBuffer = ShortArray(VAD_WINDOW)
        val floatBuffer = FloatArray(VAD_WINDOW)
        var lastSpeech = false
        while (running.get()) {
            val count = audioRecord.read(shortBuffer, 0, shortBuffer.size)
            if (count < 0) error("Error de lectura del micrófono ($count)")
            if (count == 0) continue
            for (i in 0 until count) floatBuffer[i] = shortBuffer[i] / 32768.0f
            vad.acceptWaveform(if (count == VAD_WINDOW) floatBuffer else floatBuffer.copyOf(count))
            drainVad(vad)

            val speech = vad.isSpeechDetected()
            if (speech != lastSpeech) {
                lastSpeech = speech
                mainHandler.post {
                    if (running.get()) {
                        status.text = if (speech) "Voz detectada…" else "Escuchando. Habla con naturalidad; la frase se cierra tras una pausa."
                    }
                }
            }
        }
        vad.flush()
        drainVad(vad)
    }

    private fun drainVad(vad: Vad) {
        while (!vad.empty()) {
            val segment = vad.front()
            vad.pop()
            if (segment.samples.size >= MIN_SEGMENT_SAMPLES) enqueueRecognition(segment.samples)
        }
    }

    private fun enqueueRecognition(samples: FloatArray) {
        val audioMs = samples.size * 1000L / SAMPLE_RATE
        try {
            asrExecutor.execute {
                try {
                    val current = recognizer ?: return@execute
                    val t0 = SystemClock.elapsedRealtime()
                    val stream = current.createStream()
                    stream.acceptWaveform(samples, SAMPLE_RATE)
                    current.decode(stream)
                    val text = current.getResult(stream).text.trim()
                    stream.release()
                    val decodeMs = SystemClock.elapsedRealtime() - t0
                    mainHandler.post {
                        stats.add(audioMs, decodeMs)
                        if (text.isNotBlank()) appendTranscript(text, audioMs, decodeMs)
                        refreshMetrics()
                    }
                } catch (e: Exception) {
                    mainHandler.post { status.text = "Error de reconocimiento: ${e.message ?: "desconocido"}" }
                }
            }
        } catch (_: RejectedExecutionException) {
            // El ejecutor ya no acepta trabajo; se descarta la frase.
        }
    }

    private fun appendTranscript(text: String, audioMs: Long, decodeMs: Long) {
        val old = transcript.text.toString()
        val prefix = if (old.startsWith("Aquí aparecerán")) "" else "$old\n\n"
        transcript.text = prefix + "• " + text +
            String.format(Locale.getDefault(), "\n   audio %.1f s · decodificación %d ms", audioMs / 1000.0, decodeMs)
    }

    private fun stopListening() {
        if (!running.get()) return
        status.text = "Deteniendo…"
        stopButton.isEnabled = false
        running.set(false) // el hilo de captura libera el micrófono, el VAD y el reconocedor al salir
    }

    private fun releaseRecognizerAfterPendingWork() {
        try {
            asrExecutor.execute {
                try { recognizer?.release() } catch (_: Exception) {}
                recognizer = null
            }
        } catch (_: RejectedExecutionException) {
            try { recognizer?.release() } catch (_: Exception) {}
            recognizer = null
        }
    }

    // ---------------------------------------------------------------- medición (Fase 0)

    private fun refreshMetrics() {
        val snap = DeviceMetrics.snapshot(this, filesDir)
        if (running.get()) {
            if (snap.appPssMb > peakPssMb) peakPssMb = snap.appPssMb
            if (snap.availRamMb < minAvailMb) minAvailMb = snap.availRamMb
        }
        metricsView.text = buildString {
            append(DeviceMetrics.describe(snap))
            append("\nModelo en disco: ${modelSizeMb()} MB")
            if (modelLoadMs >= 0) append(" · carga modelo+VAD: $modelLoadMs ms")
            append("\n")
            append(statsLine())
        }
    }

    private fun statsLine(): String =
        if (stats.count == 0) "Frases reconocidas: 0"
        else String.format(
            Locale.getDefault(),
            "Frases: %d · decodif. media %d ms · máx %d ms · RTF %.2f",
            stats.count, stats.avgDecodeMs, stats.maxDecodeMs, stats.rtf
        )

    private fun buildReport(): String = buildString {
        appendLine("ORION Voice Lab 0.3 — informe de medición")
        appendLine(DeviceMetrics.deviceSummary())
        val now = DeviceMetrics.snapshot(this@MainActivity, filesDir)
        appendLine("Ahora:")
        appendLine(DeviceMetrics.describe(now))
        appendLine("Modelo en disco: ${modelSizeMb()} MB")
        appendLine(if (modelLoadMs >= 0) "Carga de modelo + VAD: $modelLoadMs ms" else "Carga de modelo + VAD: sin medir")
        appendLine(statsLine())
        if (stats.count > 0) {
            appendLine(String.format(Locale.getDefault(), "Audio total reconocido: %.1f s", stats.audioMs / 1000.0))
        }
        val begin = startSnapshot
        if (begin != null) {
            val end = endSnapshot
            val seconds = ((if (end != null && sessionEndMs > 0) sessionEndMs else SystemClock.elapsedRealtime()) - sessionStartMs) / 1000
            appendLine("Sesión de escucha: $seconds s${if (end == null) " (en curso)" else ""}")
            appendLine("Pico de memoria de ORION (PSS): $peakPssMb MB · mínimo de RAM libre: ${if (minAvailMb == Long.MAX_VALUE) "n/d" else "$minAvailMb MB"}")
            appendLine("Batería inicio: ${begin.batteryPercent} % · temp. ${fmtTemp(begin.batteryTempC)}")
            if (end != null) {
                appendLine("Batería fin: ${end.batteryPercent} % · temp. ${fmtTemp(end.batteryTempC)} · térmico: ${end.thermalStatus}")
            }
        } else {
            appendLine("Sesión de escucha: sin datos todavía")
        }
        appendLine("Parámetros VAD: umbral $VAD_THRESHOLD · pausa de cierre $VAD_MIN_SILENCE_S s · máx. frase $VAD_MAX_SPEECH_S s")
    }

    private fun fmtTemp(value: Float): String =
        if (value.isNaN()) "n/d" else String.format(Locale.getDefault(), "%.1f °C", value)

    private fun copyReport() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("ORION informe", buildReport()))
        Toast.makeText(this, "Informe copiado al portapapeles", Toast.LENGTH_SHORT).show()
    }

    private fun resetMeasurements() {
        stats.reset()
        peakPssMb = 0L
        minAvailMb = Long.MAX_VALUE
        if (!running.get()) {
            startSnapshot = null
            endSnapshot = null
        }
        transcript.text = "Aquí aparecerán las transcripciones.\n\nEl audio se procesa en el teléfono y no se envía a ningún servidor."
        refreshMetrics()
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onDestroy() {
        destroyed = true
        running.set(false)
        mainHandler.removeCallbacks(metricsTicker)
        super.onDestroy()
    }
}
