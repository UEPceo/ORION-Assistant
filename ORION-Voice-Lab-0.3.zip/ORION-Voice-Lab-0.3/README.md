# ORION Voice Lab 0.3

Segunda iteración del laboratorio de voz de ORION. Sobre la 0.2 añade **Silero VAD** para segmentar las frases y un **panel de medición** para la Fase 0.

## Qué cambia respecto a 0.2

- **Silero VAD** (vía sherpa-onnx) sustituye al umbral de energía RMS. Decide dónde empieza y acaba cada frase y conserva el arranque de la frase, que antes podía perderse.
- `silero_vad.onnx` (644 KB) va dentro de `app/src/main/assets/`, extraído del APK de sherpa-onnx 2.0.1 que se aportó. SHA-256: `9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6`.
- **Panel de medición**: RAM total y libre, memoria de ORION (PSS), batería, temperatura de batería, estado térmico de Android, almacenamiento libre, tamaño del modelo, tiempo de carga de modelo + VAD, tiempo de decodificación por frase y factor de tiempo real (RTF). Se refresca cada 15 s mientras se escucha.
- Botón **Copiar informe**: deja en el portapapeles un informe de texto para pegarlo en el chat o en el documento de seguimiento.
- El reconocedor ya no se libera mientras hay una frase decodificándose (se libera por el mismo hilo de decodificación).
- Cada frase muestra su duración de audio y su tiempo de decodificación.

## Qué sigue sin incorporar

- No es streaming token a token: se decodifica cada frase completa tras la pausa.
- No incorpora TTS, LLM, memoria, llamadas virtuales ni tareas autónomas.
- Sin reproducción de audio (no hay `AudioTrack` en esta versión).

## Estado de validación

**No se ha compilado ni probado.** El entorno donde se escribió no tiene Android SDK, Gradle ni acceso a Internet. Lo único comprobado es que el APK de sherpa-onnx 2.0.1 contiene las clases `Vad`, `VadModelConfig` y `SileroVadModelConfig` con los constructores usados aquí. El código apunta a `sherpa-onnx v1.13.8` (JitPack); si Gradle no resuelve esa versión o la API difiere, ajustar la versión o la llamada antes de cambiar de motor.

## Modelos y licencias

- Moonshine Base ES: licencia Moonshine AI Community License (no comercial; uso comercial limitado a organizaciones con ingresos anuales inferiores a 1.000.000 USD). Leer el texto completo en el `LICENSE` del modelo antes de distribuir.
- Silero VAD: MIT.
- sherpa-onnx: Apache 2.0.

## Abrir y compilar

1. Abrir `ORION-Voice-Lab-0.3` en Android Studio (JDK 17, Android SDK 35).
2. Sincronizar Gradle (Google, Maven Central y JitPack).
3. Ejecutar `app` en un dispositivo Android ARM64.
4. Pulsar **Descargar modelo español (una vez)** con Wi-Fi.
5. Pulsar **Iniciar reconocimiento**, conceder el micrófono y hablar.
6. Tras unos minutos, pulsar **Copiar informe** y pegarlo en el chat de ORION.

## Parámetros ajustables (MainActivity.kt)

| Constante | Valor | Efecto |
| --- | --- | --- |
| `VAD_THRESHOLD` | 0,5 | Sensibilidad del VAD; bajar si no detecta voz baja, subir si hay falsos positivos |
| `VAD_MIN_SILENCE_S` | 0,5 s | Pausa que cierra la frase; menos = responde antes, pero corta frases con pausas |
| `VAD_MAX_SPEECH_S` | 12 s | Longitud máxima de una frase |
